
import React from 'react';
import { PredictionResult, RiskLevel } from '../types';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell, PieChart, Pie } from 'recharts';

interface RiskDashboardProps {
  result: PredictionResult;
  onReset: () => void;
}

const RiskDashboard: React.FC<RiskDashboardProps> = ({ result, onReset }) => {
  const getRiskColor = (level: RiskLevel) => {
    switch (level) {
      case RiskLevel.LOW: return 'text-emerald-500';
      case RiskLevel.MODERATE: return 'text-orange-500';
      case RiskLevel.HIGH: return 'text-red-500';
    }
  };

  const getRiskBg = (level: RiskLevel) => {
    switch (level) {
      case RiskLevel.LOW: return 'bg-emerald-50';
      case RiskLevel.MODERATE: return 'bg-orange-50';
      case RiskLevel.HIGH: return 'bg-red-50';
    }
  };

  const chartData = result.shapAnalysis.map(item => ({
    name: item.feature,
    impact: Math.abs(item.impact * 100),
    direction: item.impact > 0 ? 'Increase Risk' : 'Decrease Risk',
    color: item.impact > 0 ? '#ef4444' : '#10b981'
  }));

  const pieData = [
    { name: 'Risk', value: result.riskScore, color: getRiskColor(result.riskLevel).replace('text', '#').replace('-500', '') },
    { name: 'Remaining', value: 100 - result.riskScore, color: '#e2e8f0' }
  ];

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      {/* Summary Header */}
      <div className={`p-8 rounded-3xl border ${getRiskBg(result.riskLevel)} border-opacity-50 flex flex-col md:flex-row items-center gap-8 shadow-sm`}>
        <div className="relative w-48 h-48">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={pieData}
                cx="50%"
                cy="50%"
                innerRadius={60}
                outerRadius={80}
                paddingAngle={0}
                dataKey="value"
                startAngle={90}
                endAngle={450}
              >
                {pieData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
            </PieChart>
          </ResponsiveContainer>
          <div className="absolute inset-0 flex flex-col items-center justify-center">
            <span className={`text-4xl font-bold ${getRiskColor(result.riskLevel)}`}>{result.riskScore}%</span>
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Risk Score</span>
          </div>
        </div>

        <div className="flex-1 text-center md:text-left">
          <div className="flex items-center justify-center md:justify-start gap-3 mb-2">
            <h2 className={`text-3xl font-extrabold ${getRiskColor(result.riskLevel)}`}>
              {result.riskLevel}
            </h2>
            <span className="px-3 py-1 bg-white border border-slate-200 rounded-full text-xs font-bold text-slate-500 shadow-sm">
              {result.confidence}% Confidence
            </span>
          </div>
          <p className="text-slate-600 leading-relaxed mb-4 max-w-2xl">
            {result.aiReasoning}
          </p>
          <button 
            onClick={onReset}
            className="text-sm font-bold text-blue-600 hover:text-blue-700 flex items-center gap-1 mx-auto md:mx-0 transition-colors"
          >
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10 19l-7-7m0 0l7-7m-7 7h18" /></svg>
            Enter New Patient Data
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* SHAP Explanation */}
        <div className="bg-white p-8 rounded-2xl shadow-xl border border-slate-100">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-xl font-bold text-slate-800">Explainable AI (XAI)</h3>
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest bg-slate-100 px-2 py-1 rounded">SHAP Values</span>
          </div>
          <div className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                layout="vertical"
                data={chartData}
                margin={{ top: 5, right: 30, left: 40, bottom: 5 }}
              >
                <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#f1f5f9" />
                <XAxis type="number" hide />
                <YAxis 
                  dataKey="name" 
                  type="category" 
                  width={100} 
                  tick={{ fontSize: 12, fontWeight: 500, fill: '#64748b' }} 
                />
                <Tooltip 
                  cursor={{ fill: '#f8fafc' }}
                  content={({ active, payload }) => {
                    if (active && payload && payload.length) {
                      const data = payload[0].payload;
                      return (
                        <div className="bg-slate-900 text-white p-3 rounded-lg text-xs shadow-xl">
                          <p className="font-bold mb-1">{data.name}</p>
                          <p className={data.impact > 0 ? 'text-red-400' : 'text-emerald-400'}>
                            Impact: {data.direction}
                          </p>
                        </div>
                      );
                    }
                    return null;
                  }}
                />
                <Bar dataKey="impact" radius={[0, 4, 4, 0]}>
                  {chartData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
          <p className="mt-4 text-xs text-slate-400 leading-relaxed italic">
            This visualization shows the relative contribution of each clinical feature to the risk score. Red indicates factors increasing risk, green indicates mitigating factors.
          </p>
        </div>

        {/* Personalized Recommendations */}
        <div className="space-y-4">
          <h3 className="text-xl font-bold text-slate-800">Clinical Recommendations</h3>
          <div className="grid grid-cols-1 gap-4">
            {result.recommendations.map((rec, i) => (
              <div key={i} className="bg-white p-5 rounded-xl border border-slate-100 shadow-sm hover:shadow-md transition-shadow flex items-start gap-4">
                <div className={`p-2 rounded-lg shrink-0 ${
                  rec.category === 'Medical' ? 'bg-red-50 text-red-500' :
                  rec.category === 'Diet' ? 'bg-blue-50 text-blue-500' :
                  rec.category === 'Exercise' ? 'bg-emerald-50 text-emerald-500' :
                  'bg-orange-50 text-orange-500'
                }`}>
                  {rec.category === 'Medical' && <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z" /></svg>}
                  {rec.category === 'Diet' && <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 6l3 1m0 0l-3 9a5.002 5.002 0 006.001 0M6 7l3 9M6 7l6-2m6 2l3-1m-3 1l-3 9a5.002 5.002 0 006.001 0M18 7l3 9m-3-9l-6-2m0-2v2m0 16V5m0 16H9m3 0h3" /></svg>}
                  {rec.category === 'Exercise' && <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>}
                  {rec.category === 'Lifestyle' && <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>}
                </div>
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">{rec.category}</span>
                    <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold uppercase ${
                      rec.priority === 'High' ? 'bg-red-100 text-red-700' : 'bg-slate-100 text-slate-600'
                    }`}>
                      {rec.priority} Priority
                    </span>
                  </div>
                  <p className="text-sm text-slate-700 font-medium">{rec.text}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default RiskDashboard;
