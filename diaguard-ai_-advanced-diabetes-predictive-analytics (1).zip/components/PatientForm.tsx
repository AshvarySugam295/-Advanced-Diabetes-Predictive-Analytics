
import React, { useState } from 'react';
import { PatientData, Gender, SmokingStatus } from '../types';

interface PatientFormProps {
  onSubmit: (data: PatientData) => void;
  isLoading: boolean;
}

const PatientForm: React.FC<PatientFormProps> = ({ onSubmit, isLoading }) => {
  const [formData, setFormData] = useState<PatientData>({
    age: 45,
    gender: Gender.MALE,
    bmi: 26.5,
    systolicBP: 120,
    diastolicBP: 80,
    glucose: 95,
    insulin: 15,
    hba1c: 5.4,
    familyHistory: false,
    physicalActivity: 3,
    dietQuality: 'Moderate',
    smokingStatus: SmokingStatus.NEVER,
    conditions: []
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    const val = type === 'checkbox' ? (e.target as HTMLInputElement).checked : value;
    
    setFormData(prev => ({
      ...prev,
      [name]: type === 'number' ? parseFloat(value) : val
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(formData);
  };

  const InputField = ({ label, name, type, min, max, step, placeholder, info }: any) => (
    <div className="space-y-1">
      <label className="text-sm font-semibold text-slate-700 flex items-center justify-between">
        {label}
        {info && <span className="text-[10px] text-slate-400 font-normal uppercase">{info}</span>}
      </label>
      <input
        type={type}
        name={name}
        min={min}
        max={max}
        step={step}
        placeholder={placeholder}
        value={(formData as any)[name]}
        onChange={handleChange}
        className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all outline-none"
        required
      />
    </div>
  );

  return (
    <form onSubmit={handleSubmit} className="space-y-8 bg-white p-8 rounded-2xl shadow-xl border border-slate-100">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {/* Basic Info */}
        <div className="space-y-6">
          <h3 className="text-lg font-bold text-blue-600 flex items-center gap-2">
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" /></svg>
            Demographics
          </h3>
          <InputField label="Age" name="age" type="number" min="0" max="120" info="Years" />
          <div className="space-y-1">
            <label className="text-sm font-semibold text-slate-700">Gender</label>
            <select name="gender" value={formData.gender} onChange={handleChange} className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-lg outline-none">
              <option value={Gender.MALE}>Male</option>
              <option value={Gender.FEMALE}>Female</option>
              <option value={Gender.OTHER}>Other</option>
            </select>
          </div>
          <InputField label="BMI" name="bmi" type="number" min="10" max="60" step="0.1" info="kg/m²" />
        </div>

        {/* Clinical Markers */}
        <div className="space-y-6">
          <h3 className="text-lg font-bold text-emerald-600 flex items-center gap-2">
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" /></svg>
            Biomarkers
          </h3>
          <InputField label="Glucose" name="glucose" type="number" min="50" max="400" info="Fasting (mg/dL)" />
          <InputField label="HbA1c" name="hba1c" type="number" min="3" max="15" step="0.1" info="%" />
          <InputField label="Insulin" name="insulin" type="number" min="0" max="500" info="pmol/L" />
        </div>

        {/* Lifestyle */}
        <div className="space-y-6">
          <h3 className="text-lg font-bold text-orange-600 flex items-center gap-2">
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>
            Lifestyle
          </h3>
          <InputField label="Physical Activity" name="physicalActivity" type="number" min="0" max="100" info="Hrs/Week" />
          <div className="space-y-1">
            <label className="text-sm font-semibold text-slate-700">Smoking</label>
            <select name="smokingStatus" value={formData.smokingStatus} onChange={handleChange} className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-lg outline-none">
              <option value={SmokingStatus.NEVER}>Never</option>
              <option value={SmokingStatus.FORMER}>Former</option>
              <option value={SmokingStatus.CURRENT}>Current</option>
            </select>
          </div>
          <div className="flex items-center gap-3 p-4 bg-slate-50 rounded-lg mt-4">
            <input
              type="checkbox"
              name="familyHistory"
              id="familyHistory"
              checked={formData.familyHistory}
              onChange={handleChange}
              className="w-5 h-5 text-blue-600 rounded"
            />
            <label htmlFor="familyHistory" className="text-sm font-semibold text-slate-700">
              Family History of Diabetes
            </label>
          </div>
        </div>
      </div>

      <div className="pt-6 border-t border-slate-100 flex items-center justify-between">
        <p className="text-xs text-slate-400 italic max-w-md">
          Note: These inputs are used for an advanced ML simulation. Ensure data accuracy for better risk profiling.
        </p>
        <button
          type="submit"
          disabled={isLoading}
          className={`px-8 py-3 rounded-xl font-bold text-white transition-all transform hover:scale-105 active:scale-95 flex items-center gap-2 ${
            isLoading 
            ? 'bg-slate-400 cursor-not-allowed' 
            : 'bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 shadow-lg shadow-blue-200'
          }`}
        >
          {isLoading ? (
            <>
              <svg className="animate-spin h-5 w-5 text-white" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
              Processing Clinical Data...
            </>
          ) : (
            <>
              Run Diagnostic Engine
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M14 5l7 7m0 0l-7 7m7-7H3" /></svg>
            </>
          )}
        </button>
      </div>
    </form>
  );
};

export default PatientForm;
