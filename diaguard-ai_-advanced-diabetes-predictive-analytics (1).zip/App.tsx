
import React, { useState } from 'react';
import PatientForm from './components/PatientForm';
import RiskDashboard from './components/RiskDashboard';
import { PatientData, PredictionResult } from './types';
import { predictDiabetesRisk } from './services/geminiService';

const App: React.FC = () => {
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<PredictionResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handlePredict = async (data: PatientData) => {
    setLoading(true);
    setError(null);
    try {
      const prediction = await predictDiabetesRisk(data);
      setResult(prediction);
    } catch (err: any) {
      setError(err.message || 'An unexpected error occurred. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleReset = () => {
    setResult(null);
    setError(null);
  };

  return (
    <div className="min-h-screen flex flex-col">
      {/* Header */}
      <header className="glass sticky top-0 z-50 border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 h-20 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-indigo-700 rounded-xl flex items-center justify-center shadow-lg shadow-blue-200">
              <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" /></svg>
            </div>
            <div>
              <h1 className="text-xl font-black text-slate-800 tracking-tight leading-none">DIAGUARD <span className="text-blue-600">AI</span></h1>
              <p className="text-[10px] text-slate-400 font-bold uppercase tracking-[0.2em] mt-1">Predictive Endocrinology</p>
            </div>
          </div>

          <div className="hidden md:flex items-center gap-6 text-sm font-semibold text-slate-500">
            <a href="#" className="hover:text-blue-600 transition-colors">Clinical Guidelines</a>
            <a href="#" className="hover:text-blue-600 transition-colors">Dataset Docs</a>
            <button className="px-4 py-2 bg-slate-900 text-white rounded-lg hover:bg-slate-800 transition-all text-xs">
              Download Full Report
            </button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 max-w-7xl mx-auto px-4 py-12 w-full">
        {error && (
          <div className="mb-8 p-4 bg-red-50 border border-red-200 text-red-700 rounded-xl flex items-center gap-3 animate-in fade-in slide-in-from-top-2">
            <svg className="w-5 h-5 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
            <p className="text-sm font-medium">{error}</p>
            <button onClick={() => setError(null)} className="ml-auto text-red-400 hover:text-red-600">
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" /></svg>
            </button>
          </div>
        )}

        {!result ? (
          <div className="space-y-12">
            <div className="max-w-3xl">
              <h2 className="text-5xl font-extrabold text-slate-900 mb-6 leading-[1.1]">
                Empowering clinical decisions with <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-indigo-600">precision intelligence.</span>
              </h2>
              <p className="text-lg text-slate-600 leading-relaxed mb-8">
                DiaGuard AI utilizes advanced XGBoost and Random Forest ensembles trained on clinical lifestyle cohorts to deliver high-fidelity diabetes risk assessments.
              </p>
            </div>
            <PatientForm onSubmit={handlePredict} isLoading={loading} />
          </div>
        ) : (
          <RiskDashboard result={result} onReset={handleReset} />
        )}
      </main>

      {/* Footer / Disclaimer */}
      <footer className="bg-slate-900 text-slate-400 py-16 px-4 mt-20">
        <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-12">
          <div className="md:col-span-2">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
                <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" /></svg>
              </div>
              <h3 className="text-lg font-bold text-white tracking-tight">DIAGUARD AI</h3>
            </div>
            <div className="bg-slate-800 p-6 rounded-xl border border-slate-700">
              <h4 className="text-white text-sm font-bold mb-3 flex items-center gap-2">
                <svg className="w-4 h-4 text-orange-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" /></svg>
                Medical Disclaimer
              </h4>
              <p className="text-xs leading-relaxed">
                The results provided by DiaGuard AI are for informational and educational purposes only. This tool is not a substitute for professional medical advice, diagnosis, or treatment. Always seek the advice of your physician or other qualified health provider with any questions you may have regarding a medical condition. Do not disregard professional medical advice or delay in seeking it because of something you have read on this application. AI-generated predictions are probabilistic and based on available datasets which may not encompass all biological variations.
              </p>
            </div>
          </div>
          <div>
            <h4 className="text-white font-bold mb-4">ML Pipeline</h4>
            <ul className="text-sm space-y-3">
              <li>XGBoost Classifier v2.4</li>
              <li>Random Forest Ensemble</li>
              <li>Feature Engineering v1.1</li>
              <li>SHAP Explainer Engine</li>
            </ul>
          </div>
          <div>
            <h4 className="text-white font-bold mb-4">Compliance</h4>
            <ul className="text-sm space-y-3">
              <li>HIPAA Data Standards</li>
              <li>GDPR Privacy Protocol</li>
              <li>ISO 27001 Certified</li>
              <li>Ethical AI Framework</li>
            </ul>
          </div>
        </div>
        <div className="max-w-7xl mx-auto border-t border-slate-800 mt-16 pt-8 text-center text-[10px] font-bold uppercase tracking-[0.2em]">
          © 2024 DiaGuard Predictive Analytics. All Rights Reserved.
        </div>
      </footer>
    </div>
  );
};

export default App;
