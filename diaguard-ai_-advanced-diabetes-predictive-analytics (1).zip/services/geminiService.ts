
import { GoogleGenAI, Type } from "@google/genai";
import { PatientData, PredictionResult, RiskLevel } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const PREDICTION_SCHEMA = {
  type: Type.OBJECT,
  properties: {
    riskScore: { type: Type.NUMBER, description: "A calculated risk score from 0-100." },
    riskLevel: { type: Type.STRING, description: "One of 'Low Risk', 'Moderate Risk', 'High Risk'." },
    confidence: { type: Type.NUMBER, description: "Confidence percentage of the prediction (0-100)." },
    aiReasoning: { type: Type.STRING, description: "Detailed clinical reasoning behind the prediction." },
    shapAnalysis: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          feature: { type: Type.STRING },
          impact: { type: Type.NUMBER, description: "Value between -1 and 1 representing contribution to risk. Positive increases risk." },
          value: { type: Type.STRING }
        }
      }
    },
    recommendations: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          category: { type: Type.STRING },
          priority: { type: Type.STRING },
          text: { type: Type.STRING }
        }
      }
    }
  },
  required: ["riskScore", "riskLevel", "confidence", "aiReasoning", "shapAnalysis", "recommendations"]
};

export async function predictDiabetesRisk(data: PatientData): Promise<PredictionResult> {
  const prompt = `
    As a world-class medical AI specializing in endocrinology, perform a diabetes risk assessment for the following patient profile:
    - Age: ${data.age}
    - Gender: ${data.gender}
    - BMI: ${data.bmi}
    - BP: ${data.systolicBP}/${data.diastolicBP}
    - Fasting Glucose: ${data.glucose} mg/dL
    - Insulin: ${data.insulin} pmol/L
    - HbA1c: ${data.hba1c}%
    - Family History: ${data.familyHistory ? 'Yes' : 'No'}
    - Physical Activity: ${data.physicalActivity} hrs/week
    - Diet Quality: ${data.dietQuality}
    - Smoking Status: ${data.smokingStatus}
    - Existing Conditions: ${data.conditions.join(', ')}

    Perform a multi-model simulation (Logistic Regression, Random Forest, XGBoost) and provide a consensus-based risk prediction.
    Generate SHAP-like feature importance analysis for the top 5 contributing factors.
    Provide personalized, actionable preventive recommendations based on ADA (American Diabetes Association) guidelines.
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-pro-preview",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: PREDICTION_SCHEMA,
        thinkingConfig: { thinkingBudget: 4000 }
      },
    });

    const result = JSON.parse(response.text);
    return result as PredictionResult;
  } catch (error) {
    console.error("Prediction error:", error);
    throw new Error("Failed to generate prediction. Please ensure clinical markers are within reasonable ranges.");
  }
}
