
export enum Gender {
  MALE = 'Male',
  FEMALE = 'Female',
  OTHER = 'Other'
}

export enum SmokingStatus {
  NEVER = 'Never',
  FORMER = 'Former',
  CURRENT = 'Current'
}

export enum RiskLevel {
  LOW = 'Low Risk',
  MODERATE = 'Moderate Risk',
  HIGH = 'High Risk'
}

export interface PatientData {
  age: number;
  gender: Gender;
  bmi: number;
  systolicBP: number;
  diastolicBP: number;
  glucose: number;
  insulin: number;
  hba1c: number;
  familyHistory: boolean;
  physicalActivity: number; // hours per week
  dietQuality: string;
  smokingStatus: SmokingStatus;
  conditions: string[];
}

export interface ShapValue {
  feature: string;
  impact: number; // -1 to 1 impact score
  value: string | number;
}

export interface PredictionResult {
  riskScore: number; // 0 to 100
  riskLevel: RiskLevel;
  confidence: number; // percentage
  shapAnalysis: ShapValue[];
  recommendations: Recommendation[];
  aiReasoning: string;
}

export interface Recommendation {
  category: 'Diet' | 'Exercise' | 'Medical' | 'Lifestyle';
  priority: 'High' | 'Medium' | 'Low';
  text: string;
}
